(function() {

    menuLink.addEventListener('click' , function (evt) {

        document.getElementById('layout').classList.toggle('active');

        evt.preventDefault();
    });

}());
